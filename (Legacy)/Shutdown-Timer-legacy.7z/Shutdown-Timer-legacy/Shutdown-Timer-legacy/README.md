# Shutdown-Timer
Simple Shutdown Timer (Console)

Compiler: Visual Studio 2022+

Architecture: x64

## Set-up compile environment:
Needs:
- Visual Studio 2022+ with C++ Compiler

VS Project Configurations:
1. C/C++ → Command Line → Additional Options → Add "/utf-8".
2. Advanced → Set "Character Set" to "Use Unicode Character Set".
